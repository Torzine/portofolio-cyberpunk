"use client"

import { useEffect, useState } from "react"
import Image from "next/image"
import { ChevronDown } from "lucide-react"

export function HeroSection() {
  const [mounted, setMounted] = useState(false)

  useEffect(() => {
    setMounted(true)
  }, [])

  return (
    <section
      id="hero"
      className="relative flex min-h-screen items-center justify-center overflow-hidden cyber-grid"
    >
      {/* Animated background particles */}
      <div className="pointer-events-none absolute inset-0">
        {mounted &&
          Array.from({ length: 30 }).map((_, i) => (
            <div
              key={i}
              className="absolute rounded-full"
              style={{
                width: `${Math.random() * 3 + 1}px`,
                height: `${Math.random() * 3 + 1}px`,
                left: `${Math.random() * 100}%`,
                top: `${Math.random() * 100}%`,
                backgroundColor:
                  i % 3 === 0
                    ? "rgba(0, 212, 255, 0.4)"
                    : i % 3 === 1
                    ? "rgba(191, 0, 255, 0.3)"
                    : "rgba(0, 255, 136, 0.3)",
                animation: `float-particle ${Math.random() * 6 + 4}s ease-in-out infinite`,
                animationDelay: `${Math.random() * 5}s`,
              }}
            />
          ))}
      </div>

      {/* Neon line accents */}
      <div className="absolute top-1/4 left-0 h-px w-full bg-gradient-to-r from-transparent via-neon-blue/20 to-transparent" />
      <div className="absolute bottom-1/4 left-0 h-px w-full bg-gradient-to-r from-transparent via-neon-purple/20 to-transparent" />

      <div className="relative z-10 mx-auto grid max-w-6xl items-center gap-12 px-6 md:grid-cols-2">
        
        {/* LEFT SIDE - TEXT */}
        <div
          className={`transition-all duration-1000 ${
            mounted ? "translate-y-0 opacity-100" : "translate-y-8 opacity-0"
          }`}
        >
          <p className="mb-4 font-mono text-sm tracking-[0.3em] text-neon-green glow-green">
            {"// HELLO WORLD"}
          </p>

          <h1 className="mb-4 font-sans text-4xl font-bold tracking-wider md:text-6xl">
            <span className="text-foreground">I'm </span>
            <span className="text-neon-blue glow-blue">
              Fanny Eko Wicaksono
            </span>
          </h1>

          <p className="mb-6 font-mono text-base text-neon-purple glow-purple md:text-lg">
            Informatics Student | Web Developer | Tech Enthusiast
          </p>

          <p className="mb-8 max-w-xl font-mono text-sm leading-relaxed text-muted-foreground md:text-base">
            Mahasiswa informatika yang passionate dalam membangun website,
            automation, dan project kolaboratif. Menjelajahi dunia digital satu
            baris kode setiap saat.
          </p>

          <div className="flex flex-col gap-4 sm:flex-row">
            <a
              href="#projects"
              className="neon-border group relative overflow-hidden rounded-lg border border-neon-blue/50 bg-neon-blue/10 px-8 py-3 font-mono text-sm tracking-wider text-neon-blue transition-all hover:bg-neon-blue/20 hover:shadow-[0_0_20px_rgba(0,212,255,0.3)]"
            >
              VIEW PROJECTS
            </a>

            <a
              href="#contact"
              className="neon-border-purple group relative overflow-hidden rounded-lg border border-neon-purple/50 bg-neon-purple/10 px-8 py-3 font-mono text-sm tracking-wider text-neon-purple transition-all hover:bg-neon-purple/20 hover:shadow-[0_0_20px_rgba(191,0,255,0.3)]"
            >
              CONTACT ME
            </a>
          </div>
        </div>

        {/* RIGHT SIDE - PHOTO */}
        <div className="flex justify-center md:justify-end">
          <div className="relative">
            <div className="absolute -inset-2 rounded-2xl bg-gradient-to-r from-neon-blue/30 to-neon-purple/30 blur-xl"></div>
            <Image
              src="/foto-formal.png"
              alt="Fanny Eko Wicaksono"
              width={400}
              height={500}
              className="relative rounded-2xl border border-neon-blue/40 shadow-[0_0_30px_rgba(0,212,255,0.2)]"
              priority
            />
          </div>
        </div>
      </div>

      {/* Scroll indicator */}
      <a
        href="#about"
        className="absolute bottom-10 left-1/2 -translate-x-1/2 animate-bounce text-neon-blue/60"
        aria-label="Scroll down"
      >
        <ChevronDown size={28} />
      </a>

      <style jsx>{`
        @keyframes float-particle {
          0%,
          100% {
            transform: translateY(0px) translateX(0px);
            opacity: 0.4;
          }
          50% {
            transform: translateY(-20px) translateX(10px);
            opacity: 1;
          }
        }
      `}</style>
    </section>
  )
}
