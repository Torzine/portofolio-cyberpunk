"use client"

import { useEffect, useState } from "react"

export function LoadingScreen() {
  const [progress, setProgress] = useState(0)
  const [isComplete, setIsComplete] = useState(false)

  useEffect(() => {
    const interval = setInterval(() => {
      setProgress((prev) => {
        if (prev >= 100) {
          clearInterval(interval)
          setTimeout(() => setIsComplete(true), 400)
          return 100
        }
        return prev + Math.random() * 15 + 5
      })
    }, 100)

    return () => clearInterval(interval)
  }, [])

  if (isComplete) return null

  return (
    <div
      className={`fixed inset-0 z-50 flex flex-col items-center justify-center bg-cyber-dark transition-opacity duration-500 ${
        progress >= 100 ? "opacity-0" : "opacity-100"
      }`}
    >
      <h1 className="mb-8 font-sans text-2xl font-bold tracking-[0.5em] text-neon-blue glow-blue md:text-4xl">
        INITIALIZING
      </h1>

      <div className="relative h-1 w-64 overflow-hidden rounded-full bg-cyber-surface md:w-80">
        <div
          className="h-full rounded-full bg-neon-blue shadow-[0_0_15px_rgba(0,212,255,0.6)] transition-all duration-200"
          style={{ width: `${Math.min(progress, 100)}%` }}
        />
      </div>

      <p className="mt-4 font-mono text-xs tracking-widest text-muted-foreground">
        {progress < 30
          ? "LOADING_ASSETS..."
          : progress < 60
          ? "COMPILING_DATA..."
          : progress < 90
          ? "CONNECTING_SYSTEMS..."
          : "SYSTEM_READY"}
      </p>

      <p className="mt-2 font-mono text-xs text-neon-blue/60">
        {Math.min(Math.round(progress), 100)}%
      </p>
    </div>
  )
}
