"use client"

import { useRef } from "react"
import { useScrollAnimation } from "@/hooks/use-scroll-animation"
import { ExternalLink, Code, Gamepad2, Globe, Users } from "lucide-react"

const projects = [
  {
    title: "PMB Campus Website",
    role: "Co-Leader",
    description:
      "Website penerimaan mahasiswa baru kampus. Memimpin tim pengembangan dan koordinasi fitur-fitur utama pendaftaran online.",
    tags: ["HTML", "CSS", "JavaScript", "Team Lead"],
    icon: Globe,
    color: "neon-blue" as const,
    link: "https://pmb.unsa.ac.id",
  },
  {
    title: "Web Development Project",
    role: "Team Member",
    description:
      "Proyek pengembangan website kolaboratif. Bertanggung jawab atas implementasi front-end dan integrasi komponen.",
    tags: ["React", "Tailwind", "Collaboration"],
    icon: Code,
    color: "neon-purple" as const,
    link: "https://github.com/Torzine/",
  },
  {
    title: "Game Automation Script",
    role: "Developer",
    description:
      "Script otomasi untuk game yang meningkatkan efisiensi gameplay.",
    tags: ["Python", "Scripting", "Automation"],
    icon: Gamepad2,
    color: "neon-green" as const,
    link: "https://github.com/Torzine",
  },
  {
    title: "Collaborative Web Projects",
    role: "Developer",
    description:
      "Berbagai website sederhana yang dikembangkan secara tim.",
    tags: ["HTML", "CSS", "JavaScript", "Teamwork"],
    icon: Users,
    color: "neon-blue" as const,
    link: "#",
  },
]

const colorMap = {
  "neon-blue": {
    border: "border-neon-blue/30 hover:border-neon-blue/60",
    shadow: "hover:shadow-[0_0_25px_rgba(0,212,255,0.15)]",
    icon: "text-neon-blue",
    glow: "glow-blue",
    tag: "border-neon-blue/30 text-neon-blue/80",
  },
  "neon-purple": {
    border: "border-neon-purple/30 hover:border-neon-purple/60",
    shadow: "hover:shadow-[0_0_25px_rgba(191,0,255,0.15)]",
    icon: "text-neon-purple",
    glow: "glow-purple",
    tag: "border-neon-purple/30 text-neon-purple/80",
  },
  "neon-green": {
    border: "border-neon-green/30 hover:border-neon-green/60",
    shadow: "hover:shadow-[0_0_25px_rgba(0,255,136,0.15)]",
    icon: "text-neon-green",
    glow: "glow-green",
    tag: "border-neon-green/30 text-neon-green/80",
  },
}

export function ProjectsSection() {
  const sectionRef = useRef<HTMLElement>(null)
  const isVisible = useScrollAnimation(sectionRef)

  return (
    <section id="projects" ref={sectionRef} className="relative py-24 md:py-32">
      <div className="mx-auto max-w-6xl px-6">
        <div
          className={`transition-all duration-700 ${
            isVisible
              ? "translate-y-0 opacity-100"
              : "translate-y-10 opacity-0"
          }`}
        >
          <p className="mb-2 font-mono text-sm tracking-[0.3em] text-neon-green glow-green">
            {"// 02. PROJECTS"}
          </p>
          <h2 className="mb-12 font-sans text-3xl font-bold tracking-wider text-foreground md:text-4xl">
            {"MY_WORK"}
            <span className="text-neon-blue">{"()"}</span>
          </h2>
        </div>

        <div className="grid gap-6 md:grid-cols-2">
          {projects.map((project, index) => {
            const Icon = project.icon
            const styles = colorMap[project.color]

            return (
              <a
                key={project.title}
                href={project.link}
                target="_blank"
                rel="noopener noreferrer"
                className={`group block cursor-pointer rounded-lg border bg-cyber-surface/50 p-6 backdrop-blur-sm transition-all duration-500 ${styles.border} ${styles.shadow} ${
                  isVisible
                    ? "translate-y-0 opacity-100"
                    : "translate-y-10 opacity-0"
                }`}
                style={{ transitionDelay: `${index * 150}ms` }}
              >
                <div className="mb-4 flex items-center justify-between">
                  <Icon className={`h-6 w-6 ${styles.icon}`} />
                  <ExternalLink className="h-4 w-4 text-muted-foreground opacity-0 transition-opacity group-hover:opacity-100" />
                </div>

                <h3
                  className={`mb-1 font-sans text-lg font-bold tracking-wider ${styles.icon} ${styles.glow}`}
                >
                  {project.title}
                </h3>
                <p className="mb-3 font-mono text-xs tracking-wider text-muted-foreground">
                  {"// "} {project.role}
                </p>
                <p className="mb-4 font-mono text-sm leading-relaxed text-muted-foreground">
                  {project.description}
                </p>

                <div className="flex flex-wrap gap-2">
                  {project.tags.map((tag) => (
                    <span
                      key={tag}
                      className={`rounded border px-2 py-1 font-mono text-xs ${styles.tag}`}
                    >
                      {tag}
                    </span>
                  ))}
                </div>
              </a>
            )
          })}
        </div>
      </div>
    </section>
  )
}
