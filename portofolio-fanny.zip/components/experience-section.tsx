"use client"

import { useRef } from "react"
import { useScrollAnimation } from "@/hooks/use-scroll-animation"
import { Briefcase, Shield } from "lucide-react"

const experiences = [
  {
    title: "Helper Operator",
    period: "2023 - 2024",
    description:
      "Pengalaman kerja industri yang membentuk disiplin kerja dan kemampuan teknis. Bertanggung jawab mengoperasikan mesin dan membantu proses produksi dengan standar tinggi.",
    highlights: ["Disiplin Kerja", "Kemampuan Teknis", "Standar Industri"],
    icon: Briefcase,
    color: "neon-blue",
  },
  {
    title: "Project & Organization Leadership",
    period: "2024 - Present",
    description:
      "Memimpin berbagai project dan aktif dalam organisasi kampus. Mengembangkan kemampuan leadership, manajemen tim, dan komunikasi.",
    highlights: ["Leadership", "Team Management", "Communication"],
    icon: Shield,
    color: "neon-purple",
  },
]

const organizations = [
  {
    title: "Ketua Umum HMTI",
    period: "2026 - 2027",
    description:
      "Terpilih sebagai Ketua Umum Himpunan Mahasiswa Teknik Informatika. Memimpin dan mengelola seluruh kegiatan himpunan.",
    status: "Upcoming",
    color: "neon-green",
  },
  {
    title: "Kader HMI - LK1",
    period: "2025 - Present",
    description:
      "Aktif sebagai kader Himpunan Mahasiswa Islam sejak mengikuti Latihan Kader 1. Mengembangkan wawasan organisasi dan leadership.",
    status: "Active",
    color: "neon-blue",
  },
]

export function ExperienceSection() {
  const sectionRef = useRef<HTMLElement>(null)
  const isVisible = useScrollAnimation(sectionRef)

  return (
    <section
      id="experience"
      ref={sectionRef}
      className="relative py-24 md:py-32"
    >
      <div className="mx-auto max-w-6xl px-6">
        <div
          className={`transition-all duration-700 ${
            isVisible
              ? "translate-y-0 opacity-100"
              : "translate-y-10 opacity-0"
          }`}
        >
          <p className="mb-2 font-mono text-sm tracking-[0.3em] text-neon-green glow-green">
            {"// 03. EXPERIENCE"}
          </p>
          <h2 className="mb-12 font-sans text-3xl font-bold tracking-wider text-foreground md:text-4xl">
            {"JOURNEY"}
            <span className="text-neon-blue">{"()"}</span>
          </h2>
        </div>

        {/* Experience Timeline */}
        <div className="relative mb-16">
          {/* Timeline line */}
          <div className="absolute top-0 left-4 h-full w-px bg-gradient-to-b from-neon-blue/50 via-neon-purple/50 to-neon-green/50 md:left-1/2" />

          <div className="space-y-12">
            {experiences.map((exp, index) => {
              const Icon = exp.icon
              const isLeft = index % 2 === 0

              return (
                <div
                  key={exp.title}
                  className={`relative flex items-start gap-8 transition-all duration-700 ${
                    isVisible
                      ? "translate-y-0 opacity-100"
                      : "translate-y-10 opacity-0"
                  }`}
                  style={{ transitionDelay: `${index * 200}ms` }}
                >
                  {/* Mobile layout */}
                  <div className="md:hidden">
                    <div className="relative ml-12">
                      {/* Timeline dot */}
                      <div
                        className={`absolute -left-12 top-1 flex h-8 w-8 items-center justify-center rounded-full border ${
                          exp.color === "neon-blue"
                            ? "border-neon-blue/50 bg-neon-blue/10"
                            : "border-neon-purple/50 bg-neon-purple/10"
                        }`}
                      >
                        <Icon
                          className={`h-4 w-4 ${
                            exp.color === "neon-blue"
                              ? "text-neon-blue"
                              : "text-neon-purple"
                          }`}
                        />
                      </div>

                      <div
                        className={`rounded-lg border bg-cyber-surface/50 p-5 backdrop-blur-sm ${
                          exp.color === "neon-blue"
                            ? "border-neon-blue/20"
                            : "border-neon-purple/20"
                        }`}
                      >
                        <p className="mb-1 font-mono text-xs tracking-wider text-neon-green">
                          {exp.period}
                        </p>
                        <h3
                          className={`mb-2 font-sans text-lg font-bold tracking-wider ${
                            exp.color === "neon-blue"
                              ? "text-neon-blue glow-blue"
                              : "text-neon-purple glow-purple"
                          }`}
                        >
                          {exp.title}
                        </h3>
                        <p className="mb-3 font-mono text-sm leading-relaxed text-muted-foreground">
                          {exp.description}
                        </p>
                        <div className="flex flex-wrap gap-2">
                          {exp.highlights.map((h) => (
                            <span
                              key={h}
                              className={`rounded border px-2 py-1 font-mono text-xs ${
                                exp.color === "neon-blue"
                                  ? "border-neon-blue/30 text-neon-blue/80"
                                  : "border-neon-purple/30 text-neon-purple/80"
                              }`}
                            >
                              {h}
                            </span>
                          ))}
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Desktop layout */}
                  <div className="hidden w-full md:grid md:grid-cols-2 md:gap-8">
                    {isLeft ? (
                      <>
                        <div className="text-right">
                          <div
                            className={`rounded-lg border bg-cyber-surface/50 p-5 backdrop-blur-sm ${
                              exp.color === "neon-blue"
                                ? "border-neon-blue/20"
                                : "border-neon-purple/20"
                            }`}
                          >
                            <p className="mb-1 font-mono text-xs tracking-wider text-neon-green">
                              {exp.period}
                            </p>
                            <h3
                              className={`mb-2 font-sans text-lg font-bold tracking-wider ${
                                exp.color === "neon-blue"
                                  ? "text-neon-blue glow-blue"
                                  : "text-neon-purple glow-purple"
                              }`}
                            >
                              {exp.title}
                            </h3>
                            <p className="mb-3 font-mono text-sm leading-relaxed text-muted-foreground">
                              {exp.description}
                            </p>
                            <div className="flex flex-wrap justify-end gap-2">
                              {exp.highlights.map((h) => (
                                <span
                                  key={h}
                                  className={`rounded border px-2 py-1 font-mono text-xs ${
                                    exp.color === "neon-blue"
                                      ? "border-neon-blue/30 text-neon-blue/80"
                                      : "border-neon-purple/30 text-neon-purple/80"
                                  }`}
                                >
                                  {h}
                                </span>
                              ))}
                            </div>
                          </div>
                        </div>
                        <div />
                      </>
                    ) : (
                      <>
                        <div />
                        <div>
                          <div
                            className={`rounded-lg border bg-cyber-surface/50 p-5 backdrop-blur-sm ${
                              exp.color === "neon-blue"
                                ? "border-neon-blue/20"
                                : "border-neon-purple/20"
                            }`}
                          >
                            <p className="mb-1 font-mono text-xs tracking-wider text-neon-green">
                              {exp.period}
                            </p>
                            <h3
                              className={`mb-2 font-sans text-lg font-bold tracking-wider ${
                                exp.color === "neon-blue"
                                  ? "text-neon-blue glow-blue"
                                  : "text-neon-purple glow-purple"
                              }`}
                            >
                              {exp.title}
                            </h3>
                            <p className="mb-3 font-mono text-sm leading-relaxed text-muted-foreground">
                              {exp.description}
                            </p>
                            <div className="flex flex-wrap gap-2">
                              {exp.highlights.map((h) => (
                                <span
                                  key={h}
                                  className={`rounded border px-2 py-1 font-mono text-xs ${
                                    exp.color === "neon-blue"
                                      ? "border-neon-blue/30 text-neon-blue/80"
                                      : "border-neon-purple/30 text-neon-purple/80"
                                  }`}
                                >
                                  {h}
                                </span>
                              ))}
                            </div>
                          </div>
                        </div>
                      </>
                    )}
                    {/* Center dot */}
                    <div
                      className={`absolute left-1/2 top-5 flex h-8 w-8 -translate-x-1/2 items-center justify-center rounded-full border ${
                        exp.color === "neon-blue"
                          ? "border-neon-blue/50 bg-neon-blue/10"
                          : "border-neon-purple/50 bg-neon-purple/10"
                      }`}
                    >
                      <Icon
                        className={`h-4 w-4 ${
                          exp.color === "neon-blue"
                            ? "text-neon-blue"
                            : "text-neon-purple"
                        }`}
                      />
                    </div>
                  </div>
                </div>
              )
            })}
          </div>
        </div>

        {/* Organizations */}
        <div
          className={`transition-all duration-700 ${
            isVisible
              ? "translate-y-0 opacity-100"
              : "translate-y-10 opacity-0"
          }`}
          style={{ transitionDelay: "400ms" }}
        >
          <h3 className="mb-6 font-sans text-xl font-bold tracking-wider text-foreground">
            {"ORGANIZATIONS"}
            <span className="text-neon-purple">{"[]"}</span>
          </h3>

          <div className="grid gap-6 md:grid-cols-2">
            {organizations.map((org) => (
              <div
                key={org.title}
                className={`rounded-lg border bg-cyber-surface/50 p-5 backdrop-blur-sm transition-all duration-300 ${
                  org.color === "neon-green"
                    ? "border-neon-green/20 hover:border-neon-green/50 hover:shadow-[0_0_20px_rgba(0,255,136,0.1)]"
                    : "border-neon-blue/20 hover:border-neon-blue/50 hover:shadow-[0_0_20px_rgba(0,212,255,0.1)]"
                }`}
              >
                <div className="mb-2 flex items-center justify-between">
                  <p className="font-mono text-xs tracking-wider text-neon-green">
                    {org.period}
                  </p>
                  <span
                    className={`rounded-full border px-3 py-0.5 font-mono text-xs ${
                      org.status === "Upcoming"
                        ? "border-neon-green/40 text-neon-green"
                        : "border-neon-blue/40 text-neon-blue"
                    }`}
                  >
                    {org.status}
                  </span>
                </div>
                <h4
                  className={`mb-2 font-sans text-lg font-bold tracking-wider ${
                    org.color === "neon-green"
                      ? "text-neon-green glow-green"
                      : "text-neon-blue glow-blue"
                  }`}
                >
                  {org.title}
                </h4>
                <p className="font-mono text-sm leading-relaxed text-muted-foreground">
                  {org.description}
                </p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}
