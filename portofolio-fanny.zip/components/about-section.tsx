"use client"

import { useRef } from "react"
import { useScrollAnimation } from "@/hooks/use-scroll-animation"
import { User, Cpu, Zap } from "lucide-react"

export function AboutSection() {
  const sectionRef = useRef<HTMLElement>(null)
  const isVisible = useScrollAnimation(sectionRef)

  const highlights = [
    {
      icon: User,
      title: "Background",
      description:
        "Mahasiswa Informatika dengan latar belakang teknik pemesinan. Kombinasi unik antara presisi teknik dan kreativitas digital.",
      color: "neon-blue",
    },
    {
      icon: Cpu,
      title: "Approach",
      description:
        "Suka belajar dengan praktik langsung dan eksplorasi teknologi baru. Setiap project adalah kesempatan untuk tumbuh.",
      color: "neon-purple",
    },
    {
      icon: Zap,
      title: "Character",
      description:
        "Mudah beradaptasi, komunikatif, dan bertanggung jawab. Percaya bahwa kolaborasi menghasilkan karya terbaik.",
      color: "neon-green",
    },
  ]

  return (
    <section
      id="about"
      ref={sectionRef}
      className="relative py-24 md:py-32"
    >
      <div className="mx-auto max-w-6xl px-6">
        <div
          className={`transition-all duration-700 ${
            isVisible
              ? "translate-y-0 opacity-100"
              : "translate-y-10 opacity-0"
          }`}
        >
          <p className="mb-2 font-mono text-sm tracking-[0.3em] text-neon-green glow-green">
            {"// 01. ABOUT ME"}
          </p>
          <h2 className="mb-12 font-sans text-3xl font-bold tracking-wider text-foreground md:text-4xl">
            {"WHO_AM_I"}
            <span className="text-neon-blue">{"()"}</span>
          </h2>
        </div>

        <div className="grid gap-6 md:grid-cols-3">
          {highlights.map((item, index) => {
            const Icon = item.icon
            const borderClass =
              item.color === "neon-blue"
                ? "border-neon-blue/30 hover:border-neon-blue/60 hover:shadow-[0_0_20px_rgba(0,212,255,0.1)]"
                : item.color === "neon-purple"
                ? "border-neon-purple/30 hover:border-neon-purple/60 hover:shadow-[0_0_20px_rgba(191,0,255,0.1)]"
                : "border-neon-green/30 hover:border-neon-green/60 hover:shadow-[0_0_20px_rgba(0,255,136,0.1)]"
            const iconColor =
              item.color === "neon-blue"
                ? "text-neon-blue"
                : item.color === "neon-purple"
                ? "text-neon-purple"
                : "text-neon-green"
            const glowClass =
              item.color === "neon-blue"
                ? "glow-blue"
                : item.color === "neon-purple"
                ? "glow-purple"
                : "glow-green"

            return (
              <div
                key={item.title}
                className={`rounded-lg border bg-cyber-surface/50 p-6 backdrop-blur-sm transition-all duration-500 ${borderClass} ${
                  isVisible
                    ? "translate-y-0 opacity-100"
                    : "translate-y-10 opacity-0"
                }`}
                style={{ transitionDelay: `${index * 200}ms` }}
              >
                <Icon className={`mb-4 h-8 w-8 ${iconColor}`} />
                <h3
                  className={`mb-3 font-sans text-lg font-bold tracking-wider ${iconColor} ${glowClass}`}
                >
                  {item.title}
                </h3>
                <p className="font-mono text-sm leading-relaxed text-muted-foreground">
                  {item.description}
                </p>
              </div>
            )
          })}
        </div>
      </div>
    </section>
  )
}
