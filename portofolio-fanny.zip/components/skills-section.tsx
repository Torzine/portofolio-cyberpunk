"use client"

import { useRef } from "react"
import { useScrollAnimation } from "@/hooks/use-scroll-animation"

const skills = [
  {
    name: "Web Development",
    level: 85,
    color: "neon-blue" as const,
  },
  {
    name: "Scripting & Automation",
    level: 75,
    color: "neon-purple" as const,
  },
  {
    name: "Team Collaboration",
    level: 90,
    color: "neon-green" as const,
  },
  {
    name: "Communication",
    level: 88,
    color: "neon-blue" as const,
  },
  {
    name: "Leadership",
    level: 82,
    color: "neon-purple" as const,
  },
]

const colorBarMap = {
  "neon-blue": {
    bar: "bg-neon-blue",
    shadow: "shadow-[0_0_10px_rgba(0,212,255,0.5)]",
    text: "text-neon-blue",
    glow: "glow-blue",
    track: "bg-neon-blue/10",
  },
  "neon-purple": {
    bar: "bg-neon-purple",
    shadow: "shadow-[0_0_10px_rgba(191,0,255,0.5)]",
    text: "text-neon-purple",
    glow: "glow-purple",
    track: "bg-neon-purple/10",
  },
  "neon-green": {
    bar: "bg-neon-green",
    shadow: "shadow-[0_0_10px_rgba(0,255,136,0.5)]",
    text: "text-neon-green",
    glow: "glow-green",
    track: "bg-neon-green/10",
  },
}

export function SkillsSection() {
  const sectionRef = useRef<HTMLElement>(null)
  const isVisible = useScrollAnimation(sectionRef)

  return (
    <section id="skills" ref={sectionRef} className="relative py-24 md:py-32">
      <div className="mx-auto max-w-4xl px-6">
        <div
          className={`transition-all duration-700 ${
            isVisible
              ? "translate-y-0 opacity-100"
              : "translate-y-10 opacity-0"
          }`}
        >
          <p className="mb-2 font-mono text-sm tracking-[0.3em] text-neon-green glow-green">
            {"// 04. SKILLS"}
          </p>
          <h2 className="mb-12 font-sans text-3xl font-bold tracking-wider text-foreground md:text-4xl">
            {"TECH_STACK"}
            <span className="text-neon-blue">{"()"}</span>
          </h2>
        </div>

        <div className="space-y-8">
          {skills.map((skill, index) => {
            const styles = colorBarMap[skill.color]

            return (
              <div
                key={skill.name}
                className={`transition-all duration-700 ${
                  isVisible
                    ? "translate-y-0 opacity-100"
                    : "translate-y-10 opacity-0"
                }`}
                style={{ transitionDelay: `${index * 100}ms` }}
              >
                <div className="mb-2 flex items-center justify-between">
                  <span
                    className={`font-mono text-sm tracking-wider ${styles.text} ${styles.glow}`}
                  >
                    {skill.name}
                  </span>
                  <span className="font-mono text-xs text-muted-foreground">
                    {skill.level}%
                  </span>
                </div>
                <div
                  className={`h-2 overflow-hidden rounded-full ${styles.track}`}
                >
                  <div
                    className={`h-full rounded-full transition-all duration-1000 ease-out ${styles.bar} ${styles.shadow}`}
                    style={{
                      width: isVisible ? `${skill.level}%` : "0%",
                      transitionDelay: `${index * 150 + 300}ms`,
                    }}
                  />
                </div>
              </div>
            )
          })}
        </div>

        {/* Decorative tech icons grid */}
        <div
          className={`mt-16 grid grid-cols-3 gap-4 md:grid-cols-5 transition-all duration-700 ${
            isVisible
              ? "translate-y-0 opacity-100"
              : "translate-y-10 opacity-0"
          }`}
          style={{ transitionDelay: "600ms" }}
        >
          {["HTML", "CSS", "JavaScript", "Python", "React", "Next.js", "Git", "Node.js", "Tailwind", "SQL"].map(
            (tech, i) => (
              <div
                key={tech}
                className={`flex items-center justify-center rounded-lg border bg-cyber-surface/30 px-3 py-3 font-mono text-xs tracking-wider transition-all duration-300 ${
                  i % 3 === 0
                    ? "border-neon-blue/20 text-neon-blue/70 hover:border-neon-blue/50 hover:text-neon-blue"
                    : i % 3 === 1
                    ? "border-neon-purple/20 text-neon-purple/70 hover:border-neon-purple/50 hover:text-neon-purple"
                    : "border-neon-green/20 text-neon-green/70 hover:border-neon-green/50 hover:text-neon-green"
                }`}
              >
                {tech}
              </div>
            )
          )}
        </div>
      </div>
    </section>
  )
}
