"use client"

import { useRef, useState } from "react"
import { useScrollAnimation } from "@/hooks/use-scroll-animation"
import { Mail, Send, Github, Linkedin, Instagram } from "lucide-react"
import { useToast } from "@/components/ui/use-toast"

export function ContactSection() {
  const sectionRef = useRef<HTMLElement>(null)
  const isVisible = useScrollAnimation(sectionRef)
  const { toast } = useToast()
  const [loading, setLoading] = useState(false)

  const socials = [
    { icon: Mail, label: "Email", href: "mailto:youremail@gmail.com" },
    { icon: Github, label: "GitHub", href: "https://github.com/username" },
    { icon: Linkedin, label: "LinkedIn", href: "https://linkedin.com/in/username" },
    { icon: Instagram, label: "Instagram", href: "https://instagram.com/username" },
  ]

  async function handleSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault()
    setLoading(true)

    const formData = new FormData(e.currentTarget)

    try {
      const response = await fetch("https://formspree.io/f/mreaagoz", {
        method: "POST",
        body: formData,
        headers: { Accept: "application/json" },
      })

      if (response.ok) {
        toast({
          title: "Message Sent 🚀",
          description: "Pesan kamu berhasil dikirim!",
        })

        e.currentTarget.reset()
      } else {
        toast({
          title: "Error ❌",
          description: "Terjadi kesalahan, coba lagi.",
          variant: "destructive",
        })
      }
    } catch {
      toast({
        title: "Network Error ⚠️",
        description: "Tidak bisa terhubung ke server.",
        variant: "destructive",
      })
    }

    setLoading(false)
  }

  return (
    <section id="contact" ref={sectionRef} className="relative py-24 md:py-32">
      <div className="mx-auto max-w-4xl px-6">
        <div
          className={`transition-all duration-700 ${isVisible ? "translate-y-0 opacity-100" : "translate-y-10 opacity-0"
            }`}
        >
          <p className="mb-2 font-mono text-sm tracking-[0.3em] text-neon-green">
            {"// 05. CONTACT"}
          </p>

          <h2 className="mb-4 font-sans text-3xl font-bold tracking-wider md:text-4xl">
            {"GET_IN_TOUCH"}
            <span className="text-neon-blue">{"()"}</span>
          </h2>
        </div>

        <div className="grid gap-12 md:grid-cols-2">
          {/* FORM */}
          <form
            onSubmit={handleSubmit}
            className="space-y-5 transition-all duration-700"
          >
            <input
              name="name"
              type="text"
              placeholder="Nama kamu..."
              required
              className="w-full rounded-lg border border-cyber-border bg-cyber-surface/50 px-4 py-3 text-sm outline-none focus:border-neon-blue/50"
            />

            <input
              name="email"
              type="email"
              placeholder="email@example.com"
              required
              className="w-full rounded-lg border border-cyber-border bg-cyber-surface/50 px-4 py-3 text-sm outline-none focus:border-neon-blue/50"
            />

            <textarea
              name="message"
              rows={5}
              placeholder="Pesan kamu..."
              required
              className="w-full resize-none rounded-lg border border-cyber-border bg-cyber-surface/50 px-4 py-3 text-sm outline-none focus:border-neon-blue/50"
            />

            <button
              type="submit"
              disabled={loading}
              className="flex items-center gap-2 rounded-lg border border-neon-blue/50 bg-neon-blue/10 px-6 py-3 text-sm text-neon-blue transition-all hover:bg-neon-blue/20 disabled:opacity-50"
            >
              <Send className="h-4 w-4" />
              {loading ? "SENDING..." : "SEND_MESSAGE"}
            </button>
          </form>

          {/* SOCIAL */}
          <div className="flex flex-col justify-center space-y-4">
            {socials.map((social) => {
              const Icon = social.icon
              return (
                <a
                  key={social.label}
                  href={social.href}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-4 rounded-lg border bg-cyber-surface/30 p-4 transition-all hover:border-neon-blue/50"
                >
                  <Icon className="h-5 w-5 text-neon-blue" />
                  <span className="text-sm">{social.label}</span>
                </a>
              )
            })}
          </div>
        </div>
      </div>
    </section>
  )
}