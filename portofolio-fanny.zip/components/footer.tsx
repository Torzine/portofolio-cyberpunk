import Link from "next/link"
import { Github, Linkedin, Instagram, Mail } from "lucide-react"

export function Footer() {
  const socials = [
    { icon: Mail, href: "mailto:fannyeko8@gmail.com", color: "neon-blue" },
    { icon: Github, href: "https://github.com/torzine", color: "neon-purple" },
    { icon: Linkedin, href: "https://www.linkedin.com/in/fanny-eko-w", color: "neon-blue" },
    { icon: Instagram, href: "https://www.instagram.com/fann_yeko", color: "neon-green" },
  ]

  return (
    <footer className="border-t border-cyber-border bg-cyber-darker py-16">
      <div className="mx-auto max-w-6xl px-6">

        {/* 4 Column Section */}
        <div className="grid gap-12 md:grid-cols-4">

          {/* Branding */}
          <div>
            <h3 className="mb-4 font-sans text-lg font-bold tracking-wider text-foreground">
              <span className="text-neon-blue glow-blue">Fanny</span>{" "}
              <span className="text-foreground">Eko</span>
            </h3>
            <p className="font-mono text-xs text-muted-foreground leading-relaxed">
              Informatics Student | Web Developer | Tech Enthusiast.
              Membangun solusi digital modern dengan pendekatan kreatif dan efisien.
            </p>
          </div>

          {/* Contact */}
          <div>
            <h4 className="mb-4 font-mono text-sm tracking-wider text-neon-purple">
              // HUBUNGI_SAYA
            </h4>
            <ul className="space-y-2 font-mono text-xs text-muted-foreground">
              <li>
                <a
                  href="mailto:fannyeko8@gmail.com"
                  className="hover:text-neon-blue transition-colors"
                >
                  fannyeko8@gmail.com
                </a>
              </li>
              <li>Sambirembe, Kalijambe, Sragen</li>
            </ul>
          </div>

          {/* Categories */}
          <div>
            <h4 className="mb-4 font-mono text-sm tracking-wider text-neon-green">
              // KATEGORI
            </h4>
            <ul className="space-y-2 font-mono text-xs text-muted-foreground">
              <li className="hover:text-neon-blue transition-colors cursor-pointer">
                Programming
              </li>
              <li className="hover:text-neon-purple transition-colors cursor-pointer">
                Teknologi
              </li>
              <li className="hover:text-neon-green transition-colors cursor-pointer">
                Gaya Hidup
              </li>
            </ul>
          </div>

          {/* Links */}
          <div>
            <h4 className="mb-4 font-mono text-sm tracking-wider text-neon-blue">
              // TAUTAN
            </h4>
            <ul className="space-y-2 font-mono text-xs text-muted-foreground">
              <li><Link href="#hero" className="hover:text-neon-blue transition-colors">Beranda</Link></li>
              <li><Link href="#about" className="hover:text-neon-purple transition-colors">Tentang Saya</Link></li>
              <li><Link href="#projects" className="hover:text-neon-green transition-colors">Portfolio</Link></li>
              <li><Link href="#education" className="hover:text-neon-blue transition-colors">Pendidikan</Link></li>
              <li><Link href="#experience" className="hover:text-neon-purple transition-colors">Pengalaman</Link></li>
              <li><Link href="#contact" className="hover:text-neon-blue transition-colors">Kontak</Link></li>
            </ul>
          </div>

        </div>

        {/* Bottom Section */}
        <div className="mt-16 border-t border-cyber-border pt-6 text-center">

          <p className="font-mono text-xs tracking-wider text-muted-foreground">
            {"// DESIGNED & BUILT WITH"}
            <span className="text-neon-blue"> PASSION </span>
            {"& "}
            <span className="text-neon-purple">CODE</span>
          </p>

          {/* Social Icons */}
          <div className="mt-4 flex justify-center gap-6">
            {socials.map((social, i) => {
              const Icon = social.icon
              return (
                <a
                  key={i}
                  href={social.href}
                  target="_blank"
                  rel="noopener noreferrer"
                  className={`transition-all duration-300 hover:scale-110 ${social.color === "neon-blue"
                      ? "text-neon-blue hover:drop-shadow-[0_0_8px_rgba(0,212,255,0.7)]"
                      : social.color === "neon-purple"
                        ? "text-neon-purple hover:drop-shadow-[0_0_8px_rgba(191,0,255,0.7)]"
                        : "text-neon-green hover:drop-shadow-[0_0_8px_rgba(0,255,136,0.7)]"
                    }`}
                >
                  <Icon size={18} />
                </a>
              )
            })}
          </div>

          <p className="mt-4 font-mono text-xs text-muted-foreground/50">
            &copy; {new Date().getFullYear()} Fanny Eko Wicaksono. All rights reserved.
          </p>

        </div>

      </div>
    </footer>
  )
}