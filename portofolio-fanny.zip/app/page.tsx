"use client"

import { LoadingScreen } from "@/components/loading-screen"
import { Navbar } from "@/components/navbar"
import { HeroSection } from "@/components/hero-section"
import { AboutSection } from "@/components/about-section"
import { ProjectsSection } from "@/components/projects-section"
import { ExperienceSection } from "@/components/experience-section"
import { SkillsSection } from "@/components/skills-section"
import { ContactSection } from "@/components/contact-section"
import { Footer } from "@/components/footer"

export default function Home() {
  return (
    <>
      <LoadingScreen />
      <div className="scanline">
        <Navbar />
        <main>
          <HeroSection />
          <div className="mx-auto max-w-6xl px-6">
            <div className="h-px w-full bg-gradient-to-r from-transparent via-neon-blue/30 to-transparent" />
          </div>
          <AboutSection />
          <div className="mx-auto max-w-6xl px-6">
            <div className="h-px w-full bg-gradient-to-r from-transparent via-neon-purple/30 to-transparent" />
          </div>
          <ProjectsSection />
          <div className="mx-auto max-w-6xl px-6">
            <div className="h-px w-full bg-gradient-to-r from-transparent via-neon-green/30 to-transparent" />
          </div>
          <ExperienceSection />
          <div className="mx-auto max-w-6xl px-6">
            <div className="h-px w-full bg-gradient-to-r from-transparent via-neon-blue/30 to-transparent" />
          </div>
          <SkillsSection />
          <div className="mx-auto max-w-6xl px-6">
            <div className="h-px w-full bg-gradient-to-r from-transparent via-neon-purple/30 to-transparent" />
          </div>
          <ContactSection />
        </main>
        <Footer />
      </div>
    </>
  )
}
